<?php
$filename = $_POST["src"];
if($_POST["action"]){
	$extension = pathinfo($filename, PATHINFO_EXTENSION); 
	$image = imagecreatefromjpeg($filename);
	$name=explode(".", basename($filename));
	header('Content-type: image/png');
	$save = "images/". $name[0] .".png";
	chmod($save,0755);
	imagepng($image, $save,0,NULL);
	imagedestroy($image); 
	$new_image = $name[0] .".png";
	echo $new_image;
	echo "<a download='".$new_image."' href='images/".$new_image."' title='".$new_image."'>Download</a>";
}
if(is_array($_FILES)) 
{
	if(is_uploaded_file($_FILES['userImage']['tmp_name'])) {
		$sourcePath = $_FILES['userImage']['tmp_name'];
		$targetPath = "images/".$_FILES['userImage']['name'];
		if(move_uploaded_file($sourcePath,$targetPath)) 
		{
		?>
			<img src="<?php echo $targetPath; ?>">
		<?php
		}
	}
}
?>